require 'test_helper'

class BeerlinesHelperTest < ActionView::TestCase
end
