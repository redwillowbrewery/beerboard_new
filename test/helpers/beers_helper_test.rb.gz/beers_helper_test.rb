require 'test_helper'

class BeersHelperTest < ActionView::TestCase
end
