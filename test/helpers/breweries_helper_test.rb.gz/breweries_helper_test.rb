require 'test_helper'

class BreweriesHelperTest < ActionView::TestCase
end
