require 'test_helper'

class StylesHelperTest < ActionView::TestCase
end
