require 'test_helper'

class DispensesHelperTest < ActionView::TestCase
end
