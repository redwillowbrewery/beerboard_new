require 'test_helper'

class LinesHelperTest < ActionView::TestCase
end
