require 'test_helper'

class BeerlinesControllerTest < ActionController::TestCase
  # test "the truth" do
  #   assert true
  # end
end
