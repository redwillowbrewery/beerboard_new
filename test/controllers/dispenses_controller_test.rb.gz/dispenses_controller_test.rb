require 'test_helper'

class DispensesControllerTest < ActionController::TestCase
  setup do
    @dispense = dispenses(:one)
  end

  test "should get index" do
    get :index
    assert_response :success
    assert_not_nil assigns(:dispenses)
  end

  test "should get new" do
    get :new
    assert_response :success
  end

  test "should create dispense" do
    assert_difference('Dispense.count') do
      post :create, dispense: { name: @dispense.name }
    end

    assert_redirected_to dispense_path(assigns(:dispense))
  end

  test "should show dispense" do
    get :show, id: @dispense
    assert_response :success
  end

  test "should get edit" do
    get :edit, id: @dispense
    assert_response :success
  end

  test "should update dispense" do
    patch :update, id: @dispense, dispense: { name: @dispense.name }
    assert_redirected_to dispense_path(assigns(:dispense))
  end

  test "should destroy dispense" do
    assert_difference('Dispense.count', -1) do
      delete :destroy, id: @dispense
    end

    assert_redirected_to dispenses_path
  end
end
